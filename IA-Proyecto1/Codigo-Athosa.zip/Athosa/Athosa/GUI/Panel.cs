﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Athosa.GUI
{
    public partial class Panel : Form
    {
        public Panel()
        {
            InitializeComponent();
        }
        private void btnDraw_Click(object sender, EventArgs e)
        {
            int width = 700;
            int height = 350;
            Graphics panel1 = new Panel.CreateGraphics();
            Pen myPen = new Pen(Brushes.Black, 1);
            Font myFont = new Font("Arial", 10);
            int lines = Convert.ToInt32(txtLines.Text);
            float x = 0f;
            float y = 0f;
            float xSpace = ((width - myPen.Width) * 1.0f / lines);
            float ySpace = ((height - myPen.Width) * 1.0f / lines);

            //vertical lines
            for (int i = 0; i < lines + 1; i++)
            {
                panel1.DrawLine(myPen, x, y, x, ySpace * lines);
                x += xSpace;
            }
            //horizontal lines
            for (int i = 0; i < lines + 1; i++)
            {
                panel1.DrawLine(myPen, x, y, xSpace * lines, y);
            }
        }

        private void Panel_Load(object sender, EventArgs e)
        {

        }
    }
}
