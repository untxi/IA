﻿/*using System;


namespace Athosa.Logic
{
    class Tuple
    {
        private int row;
        private int col;
        Tuple before;
        public bool hasBefore;
        int estimation;
        double distance;

        public Tuple(int pRow, int pCol)
        {
            row = pRow;
            col = pCol;
        }


        public int getRow()
        {
            return row;
        }
        public int getCol()
        {
            return col;
        }
        public void setRow(int pRow)
        {
            row = pRow;
        }
        public void setCol(int pCol)
        {
            col = pCol;
        }
        public void setBefore(Tuple pBefore)
        {
            before = pBefore;
            hasBefore = true;
        }
        public Tuple getBefore()
        {
            return before;
        }

        public void setEstimation(int pEstimation)
        {
            estimation = pEstimation;
        }
        public int getEstimation()
        {
            return estimation;
        }

        public void setDistance(double pDistance)
        {
            distance = pDistance;
        }

        public double getDistance()
        {
            return distance;
        }
    }

}
*/